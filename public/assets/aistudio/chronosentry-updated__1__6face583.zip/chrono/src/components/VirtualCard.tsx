import React from 'react';

/**
 * Decorative demo payment card. Generic shapes only – no real card-network logos or names.
 * The number is a fixed masked placeholder; no real card data is ever collected or displayed.
 */
export const VirtualCard: React.FC<{ balanceLabel?: string; balance?: string }> = ({ balanceLabel = 'Demo balance', balance = '$12,480.00' }) => (
  <figure
    className="relative rounded-2xl p-5 sm:p-6 overflow-hidden text-white bg-[#0B1220] border border-[#3988FF]/30 shadow-lg min-h-[210px] flex flex-col justify-between"
    aria-label="Demo card – not a real account. Masked number ending 4242."
  >
    {/* subtle decorative arcs */}
    <svg className="absolute -right-16 -top-16 w-72 h-72 opacity-40 pointer-events-none" viewBox="0 0 200 200" aria-hidden="true">
      <circle cx="100" cy="100" r="90" fill="none" stroke="#173B70" strokeWidth="22" />
      <circle cx="100" cy="100" r="55" fill="none" stroke="#3988FF" strokeOpacity="0.35" strokeWidth="2" />
    </svg>

    <div className="relative flex items-start justify-between">
      <div className="flex items-center gap-3">
        {/* generic chip */}
        <svg width="42" height="32" viewBox="0 0 42 32" aria-hidden="true">
          <rect x="1" y="1" width="40" height="30" rx="6" fill="#D9B45A" stroke="#B8923A" />
          <path d="M1 11h13M1 21h13M28 11h13M28 21h13M14 1v30M28 1v30" stroke="#8C6B22" strokeOpacity="0.7" strokeWidth="1.2" />
        </svg>
        {/* generic contactless waves */}
        <svg width="20" height="22" viewBox="0 0 20 22" aria-hidden="true">
          <path d="M5 6c2 3 2 7 0 10M9.5 3.5c3.5 4.5 3.5 10.5 0 15M14 1c5 6 5 14 0 20" fill="none" stroke="#CBD5E1" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      </div>
      {/* generic network-style mark: two overlapping rings */}
      <svg width="46" height="28" viewBox="0 0 46 28" aria-hidden="true">
        <circle cx="16" cy="14" r="12" fill="#3988FF" fillOpacity="0.85" />
        <circle cx="30" cy="14" r="12" fill="#173B70" fillOpacity="0.95" stroke="#3988FF" strokeOpacity="0.6" />
      </svg>
    </div>

    <div className="relative mt-3">
      <span className="inline-block px-2 py-0.5 rounded bg-amber-400/15 border border-amber-400/40 text-amber-200 text-xs font-mono font-bold tracking-wider">
        DEMO CARD — NO REAL ACCOUNT
      </span>
    </div>

    <div className="relative font-mono text-lg sm:text-xl font-semibold tracking-[0.18em] text-slate-100 mt-3">•••• •••• •••• 4242</div>

    <figcaption className="relative flex items-end justify-between pt-3 mt-3 border-t border-white/10 text-xs">
      <span>
        <span className="block text-xs uppercase tracking-wider text-slate-400 font-mono">Card label</span>
        <span className="font-semibold text-slate-200 font-mono tracking-wider">DEMO ACCOUNT</span>
      </span>
      <span className="text-right">
        <span className="block text-xs uppercase tracking-wider text-slate-400 font-mono">{balanceLabel}</span>
        <span className="font-semibold text-slate-100 font-mono">{balance}</span>
      </span>
    </figcaption>
  </figure>
);
